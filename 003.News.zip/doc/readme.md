211001

1. <html lang="en">  한글로 변경
2. <li> <br> 군 북 동해상으로 탄도미사일 2발 발사</li> br  삭제
3. <button class="btn"><a href="#">∨</a></button> 버튼 이나 링크,인풋 처럼 액션이 취하는 곳은 독립적으로 .... 하위로 넣을수 없음


4.마크업 주석 쓰는 법
<!-- 시작 -->
<!-- // 끝 -->


5.클래스 네이밍 규칙 지켜야
BrNews?
topmenu?

대문자 소문자 하나는 카멜 하나는 그냥 다 소문자 규칙성 없음

고전 퍼블리셔는 스네이크 방식 _선호
.sample_gnb


6.스타일은 모듈단위로 잘라서 구분
7.reset.css은 통일시키고 시작
8. css 방법론
https://jinminkim-50502.medium.com/css-bem-smacss-oocss-9e4d6beb0a38

9.[CSS] IR(Image Replacement) 기법 -웹접근성- 
 https://haneunbi.github.io/2020/06/01/css-ir/

10. favicon  생성
https://wizlogo.com/ko/favicon-generator

11. 폰트아이콘 사용 , 폰트어썸은 폰트가 두꺼운편. 
https://ionic.io/ionicons/v2